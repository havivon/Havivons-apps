﻿# Removes "Reply + Attachments" for the current Windows user: the registry
# entries Install.ps1 wrote and the folder %LOCALAPPDATA%\ReplyForwardAttachments.
#
#   powershell -ExecutionPolicy Bypass -File Uninstall.ps1 [-Quiet]

param([switch]$Quiet)

$ErrorActionPreference = 'Stop'

$ProgId = 'ReplyForwardAttachments.AddIn'
$ClassId = '{CC0A0643-7718-4640-BBA5-CFE3262F0473}'
$OfficeVersions = '16.0', '15.0'
$target = Join-Path $env:LOCALAPPDATA 'ReplyForwardAttachments'

Add-Type -AssemblyName System.Windows.Forms

function Show-Message([string]$text, [string]$icon = 'Information', [string]$buttons = 'OK') {
    if ($Quiet) { Write-Host $text; return 'OK' }
    $rtl = [System.Windows.Forms.MessageBoxOptions]::RtlReading -bor [System.Windows.Forms.MessageBoxOptions]::RightAlign
    return [System.Windows.Forms.MessageBox]::Show($text, 'השב + צרופות ל-Outlook', $buttons, $icon, 'Button1', $rtl)
}

try {
    if (-not $Quiet) {
        $answer = Show-Message 'להסיר את התוסף "השב + צרופות" מ-Outlook?' 'Question' 'OKCancel'
        if ($answer -ne 'OK') { exit 1 }
    }

    while (Get-Process -Name OUTLOOK -ErrorAction SilentlyContinue) {
        if ($Quiet) { throw 'Outlook is running. Close it and run the uninstaller again.' }
        $answer = Show-Message "Outlook פתוח כרגע.`n`nסגור את Outlook ולחץ אישור כדי להמשיך בהסרה." 'Warning' 'OKCancel'
        if ($answer -ne 'OK') { exit 1 }
        Start-Sleep -Seconds 2
    }

    Remove-Item "HKCU:\Software\Microsoft\Office\Outlook\Addins\$ProgId" -Recurse -Force -ErrorAction SilentlyContinue

    foreach ($view in 'Registry64', 'Registry32') {
        $hkcu = [Microsoft.Win32.RegistryKey]::OpenBaseKey('CurrentUser', $view)
        try {
            $hkcu.DeleteSubKeyTree("Software\Classes\CLSID\$ClassId", $false)
            $hkcu.DeleteSubKeyTree("Software\Classes\$ProgId", $false)
        }
        finally { $hkcu.Close() }
    }

    foreach ($version in $OfficeVersions) {
        $keep = "HKCU:\Software\Microsoft\Office\$version\Outlook\Resiliency\DoNotDisableAddinList"
        if (Test-Path $keep) { Remove-ItemProperty -Path $keep -Name $ProgId -ErrorAction SilentlyContinue }
    }

    Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ReplyForwardAttachments' -Recurse -Force -ErrorAction SilentlyContinue

    if (Test-Path $target) { Remove-Item $target -Recurse -Force -ErrorAction SilentlyContinue }

    Show-Message 'התוסף הוסר.' | Out-Null
    exit 0
}
catch {
    Show-Message ("ההסרה נכשלה:`n`n" + $_.Exception.Message) 'Error' | Out-Null
    exit 1
}
