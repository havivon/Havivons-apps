@echo off
rem Removes "Reply + Attachments" from Outlook for the current user (the copy Settings > Apps runs).
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Uninstall.ps1" & exit /b
