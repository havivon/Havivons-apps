﻿# Installs "Reply + Attachments" for the current Windows user.
#
# No administrator rights. Everything is written under the user's own profile:
#   files     %LOCALAPPDATA%\ReplyForwardAttachments
#   registry  HKEY_CURRENT_USER only (listed step by step below)
#
# Run Install.cmd, or for a silent install:
#   powershell -ExecutionPolicy Bypass -File Install.ps1 -Quiet

param([switch]$Quiet)

$ErrorActionPreference = 'Stop'

$ProgId = 'ReplyForwardAttachments.AddIn'
$ClassId = '{CC0A0643-7718-4640-BBA5-CFE3262F0473}'
$ClassName = 'ReplyForwardAttachments.ReplyForwardRibbon'
$DllName = 'ReplyForwardAttachments.dll'
$FriendlyName = 'Reply + Attachments'
$Description = 'Reply and Reply All that keep the original attachments. Created By Havivon'
$OldVstoKey = 'ReplyForwardAttachments'    # version 1.0 was a VSTO add-in under this name
$OfficeVersions = '16.0', '15.0'            # 16.0 = Outlook 2016 / 2019 / 2021 / Microsoft 365

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$target = Join-Path $env:LOCALAPPDATA 'ReplyForwardAttachments'

Add-Type -AssemblyName System.Windows.Forms

function Show-Message([string]$text, [string]$icon = 'Information', [string]$buttons = 'OK') {
    if ($Quiet) { Write-Host $text; return 'OK' }
    $rtl = [System.Windows.Forms.MessageBoxOptions]::RtlReading -bor [System.Windows.Forms.MessageBoxOptions]::RightAlign
    return [System.Windows.Forms.MessageBox]::Show($text, 'השב + צרופות ל-Outlook', $buttons, $icon, 'Button1', $rtl)
}

function Test-OutlookRunning { return [bool](Get-Process -Name OUTLOOK -ErrorAction SilentlyContinue) }

# Removes the add-in from Outlook's "disabled" and "crashed" lists and from
# the slow-add-in history, so an earlier bad start is not held against it.
function Clear-Resiliency([string]$version, [string[]]$names) {
    $base = "HKCU:\Software\Microsoft\Office\$version\Outlook\Resiliency"
    foreach ($list in 'DisabledItems', 'CrashingAddinList') {
        $key = Join-Path $base $list
        if (-not (Test-Path $key)) { continue }
        $item = Get-Item $key
        foreach ($valueName in $item.GetValueNames()) {
            $data = $item.GetValue($valueName)
            if ($data -isnot [byte[]]) { continue }
            $text = [System.Text.Encoding]::Unicode.GetString($data)
            foreach ($n in $names) {
                if ($text.IndexOf($n, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
                    Remove-ItemProperty -Path $key -Name $valueName -ErrorAction SilentlyContinue
                    break
                }
            }
        }
    }
    $reminders = Join-Path $base 'NotificationReminderAddinData'
    if (Test-Path $reminders) {
        $item = Get-Item $reminders
        foreach ($valueName in $item.GetValueNames()) {
            foreach ($n in $names) {
                if ($valueName.IndexOf($n, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
                    Remove-ItemProperty -Path $reminders -Name $valueName -ErrorAction SilentlyContinue
                    break
                }
            }
        }
    }
}

try {
    $sourceDll = Join-Path $here $DllName
    if (-not (Test-Path $sourceDll)) {
        throw "הקובץ $DllName חסר. יש לחלץ את כל קובץ ה-ZIP לתיקייה ולהפעיל שוב את Install.cmd."
    }

    # 1. Outlook locks the add-in file while it runs, so it has to be closed.
    while (Test-OutlookRunning) {
        if ($Quiet) { throw 'Outlook is running. Close it and run the installer again.' }
        $answer = Show-Message "Outlook פתוח כרגע.`n`nסגור את Outlook ולחץ אישור כדי להמשיך בהתקנה." 'Warning' 'OKCancel'
        if ($answer -ne 'OK') { exit 1 }
        Start-Sleep -Seconds 2
    }

    # 2. Copy the files. A file that came from the internet carries a "blocked"
    #    mark, and .NET refuses to load a blocked DLL - so the mark is removed.
    New-Item -ItemType Directory -Force $target | Out-Null
    foreach ($name in $DllName, 'Uninstall.ps1', 'Uninstall.cmd') {
        $from = Join-Path $here $name
        if (Test-Path $from) {
            Copy-Item $from (Join-Path $target $name) -Force
            Unblock-File (Join-Path $target $name) -ErrorAction SilentlyContinue
        }
    }
    $dll = Join-Path $target $DllName
    $assembly = [System.Reflection.AssemblyName]::GetAssemblyName($dll)
    $codeBase = ([Uri]$dll).AbsoluteUri

    # 3. Register the add-in's class for this user, for 64-bit and for 32-bit
    #    Outlook (each reads its own view of the registry).
    foreach ($view in 'Registry64', 'Registry32') {
        $hkcu = [Microsoft.Win32.RegistryKey]::OpenBaseKey('CurrentUser', $view)
        try {
            $clsid = $hkcu.CreateSubKey("Software\Classes\CLSID\$ClassId")
            $clsid.SetValue('', $ClassName)
            $clsid.CreateSubKey('ProgId').SetValue('', $ProgId)
            $clsid.CreateSubKey('Implemented Categories\{62C8FE65-4EBB-45e7-B440-6E39B2CDBF29}') | Out-Null
            foreach ($sub in 'InprocServer32', "InprocServer32\$($assembly.Version)") {
                $k = $clsid.CreateSubKey($sub)
                if ($sub -eq 'InprocServer32') {
                    $k.SetValue('', 'mscoree.dll')
                    $k.SetValue('ThreadingModel', 'Both')
                }
                $k.SetValue('Class', $ClassName)
                $k.SetValue('Assembly', $assembly.FullName)
                $k.SetValue('RuntimeVersion', 'v4.0.30319')
                $k.SetValue('CodeBase', $codeBase)
                $k.Close()
            }
            $clsid.Close()

            $prog = $hkcu.CreateSubKey("Software\Classes\$ProgId")
            $prog.SetValue('', $ClassName)
            $prog.CreateSubKey('CLSID').SetValue('', $ClassId)
            $prog.Close()
        }
        finally { $hkcu.Close() }
    }

    # 4. Tell Outlook to load it at startup.
    $addinKey = "HKCU:\Software\Microsoft\Office\Outlook\Addins\$ProgId"
    New-Item -Path $addinKey -Force | Out-Null
    Set-ItemProperty -Path $addinKey -Name 'LoadBehavior' -Value 3 -Type DWord
    Set-ItemProperty -Path $addinKey -Name 'FriendlyName' -Value $FriendlyName -Type String
    Set-ItemProperty -Path $addinKey -Name 'Description' -Value $Description -Type String

    # 5. Version 1.0 (VSTO) would show the same buttons twice - remove its entry.
    $oldKey = "HKCU:\Software\Microsoft\Office\Outlook\Addins\$OldVstoKey"
    if (Test-Path $oldKey) { Remove-Item $oldKey -Recurse -Force }

    # 6. Keep Outlook from switching the add-in off. Outlook times every add-in
    #    at startup and disables "slow" ones with a yellow bar; this is the same
    #    setting as choosing "Always enable this add-in" in that bar.
    foreach ($version in $OfficeVersions) {
        if (-not (Test-Path "HKCU:\Software\Microsoft\Office\$version\Outlook")) { continue }
        $keep = "HKCU:\Software\Microsoft\Office\$version\Outlook\Resiliency\DoNotDisableAddinList"
        New-Item -Path $keep -Force | Out-Null
        Set-ItemProperty -Path $keep -Name $ProgId -Value 1 -Type DWord
        Clear-Resiliency $version @($ProgId, $DllName, $OldVstoKey)
    }

    # 7. List it under Settings > Apps, so it can be removed from there.
    $uninstall = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ReplyForwardAttachments'
    New-Item -Path $uninstall -Force | Out-Null
    Set-ItemProperty -Path $uninstall -Name 'DisplayName' -Value 'Reply + Attachments for Outlook' -Type String
    Set-ItemProperty -Path $uninstall -Name 'DisplayVersion' -Value $assembly.Version.ToString(3) -Type String
    Set-ItemProperty -Path $uninstall -Name 'Publisher' -Value 'Created By Havivon' -Type String
    Set-ItemProperty -Path $uninstall -Name 'InstallLocation' -Value $target -Type String
    Set-ItemProperty -Path $uninstall -Name 'UninstallString' -Value ('"{0}"' -f (Join-Path $target 'Uninstall.cmd')) -Type String
    Set-ItemProperty -Path $uninstall -Name 'NoModify' -Value 1 -Type DWord
    Set-ItemProperty -Path $uninstall -Name 'NoRepair' -Value 1 -Type DWord

    Show-Message "ההתקנה הושלמה.`n`nהפעל את Outlook. הכפתורים ""השב + צרופות"" ו""השב לכולם + צרופות"" נמצאים בלשונית בית, ליד כפתורי השב והעבר, וגם בחלון של הודעה פתוחה." | Out-Null
    exit 0
}
catch {
    Show-Message ("ההתקנה נכשלה:`n`n" + $_.Exception.Message) 'Error' | Out-Null
    exit 1
}
