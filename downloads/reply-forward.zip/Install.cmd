@echo off
rem Installs "Reply + Attachments" for Outlook, for the current user. No administrator rights needed.
if not exist "%~dp0files\ReplyForwardAttachments.dll" goto notextracted
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0files\Install.ps1"
exit /b %errorlevel%

:notextracted
echo.
echo  The installer's files are missing.
echo.
echo  Extract the whole ZIP first: right-click the ZIP file, choose "Extract All",
echo  then run Install.cmd from the extracted folder.
echo.
pause
exit /b 1
