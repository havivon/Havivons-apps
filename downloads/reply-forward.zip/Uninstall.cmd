@echo off
rem Removes "Reply + Attachments" from Outlook for the current user.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0files\Uninstall.ps1" & exit /b
